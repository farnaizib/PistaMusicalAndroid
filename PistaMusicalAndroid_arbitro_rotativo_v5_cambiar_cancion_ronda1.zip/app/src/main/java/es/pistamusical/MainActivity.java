package es.pistamusical;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.DocumentsContract;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
  static final int PICK_FOLDER=31;
  static final int ROUNDS=4, TURN_SECONDS=15;
  int selectedSongCount=4;
  static class Track {
    Uri uri; String fileName="", title="", artist="", lyricClue="", spanishClue=""; long durationMs=0;
  }
  final ArrayList<Track> sampledTracks=new ArrayList<>();
  final ArrayList<String> players=new ArrayList<>(Arrays.asList("Jugador 1","Jugador 2"));
  final ArrayList<int[]> scoreHistory=new ArrayList<>();
  final ExecutorService worker=Executors.newSingleThreadExecutor();
  final Handler handler=new Handler();
  TextToSpeech tts;
  MediaPlayer player;
  Runnable timerRunnable;
  int[] scores=new int[2];
  int songIndex=0, round=0, playerIndex=0, refereeIndex=0, secondsLeft=TURN_SECONDS;
  boolean folderReady=false, gameStarted=false, turnActive=false, timerExpired=false, roundOneStarted=false;
  boolean titleSolved=false, artistSolved=false;
  long round3Start=0;
  Uri folderUri;
  LinearLayout root, content;
  TextView timerText, infoText, scoreboardText, refereeClueText;
  Button startTurnButton, nextButton;

  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    tts=new TextToSpeech(this, result->{ if(result==TextToSpeech.SUCCESS) tts.setLanguage(new Locale("es","ES")); });
    showSetup();
  }

  int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
  TextView text(String value,int size,int color,boolean bold){
    TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(4),dp(7),dp(4),dp(7));
    if(bold)t.setTypeface(null,1);return t;
  }
  Button button(String value){Button b=new Button(this);b.setText(value);return b;}
  void base(int bg){
    ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(12),dp(18),dp(24));root.setBackgroundColor(bg);sc.addView(root);
    LinearLayout logo=new LinearLayout(this);logo.setOrientation(LinearLayout.VERTICAL);logo.setGravity(Gravity.CENTER);logo.setPadding(dp(12),dp(12),dp(12),dp(12));logo.setBackgroundColor(0xff14233b);
    TextView mark=text("♫  PISTA MUSICAL  ♫",24,0xffffd166,true);mark.setGravity(Gravity.CENTER);logo.addView(mark);
    TextView sub=text("EL JUEGO DE ADIVINAR CANCIONES",11,0xffe7eefb,true);sub.setGravity(Gravity.CENTER);logo.addView(sub);root.addView(logo);
    content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,dp(10),0,0);root.addView(content);
    setContentView(sc);
  }
  void showSetup(){
    gameStarted=false;base(0xfff3f5fa);
    content.addView(text("PREPARA LA PARTIDA",23,0xff18233b,true));
    content.addView(text("1 · Jugadores",17,0xff18233b,true));
    Button names=button("Configurar nombres de jugadores");content.addView(names);names.setOnClickListener(v->editPlayers());
    TextView playersLabel=text("Jugadores: "+String.join(" · ",players),14,0xff334155,false);content.addView(playersLabel);
    content.addView(text("2 · Número de canciones (múltiplo de jugadores)",17,0xff18233b,true));
    Spinner songCountSpinner=new Spinner(this); ArrayList<String> songOptions=new ArrayList<>();
    int step=Math.max(2,players.size()); for(int n=step;n<=step*10;n+=step)songOptions.add(String.valueOf(n));
    ArrayAdapter<String> songAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,songOptions);songAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);songCountSpinner.setAdapter(songAdapter);
    int chosen=songOptions.indexOf(String.valueOf(selectedSongCount));if(chosen<0){selectedSongCount=step;chosen=0;}songCountSpinner.setSelection(chosen);
    songCountSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){} public void onItemSelected(AdapterView<?> p,View v,int pos,long id){try{selectedSongCount=Integer.parseInt(songOptions.get(pos));}catch(Exception ignored){}}});content.addView(songCountSpinner);
    Button folder=button(folderReady?"Cambiar carpeta de música":"Elegir carpeta de música (incluye subcarpetas)");content.addView(folder);folder.setOnClickListener(v->pickFolder());
    infoText=text(folderReady?"Partida preparada: "+sampledTracks.size()+" canciones. Las canciones siguientes permanecerán ocultas.":"Selecciona una carpeta; se sortearán " + selectedSongCount + " canciones. No se mostrará la lista.",14,0xff334155,false);content.addView(infoText);
    Button start=button("COMENZAR PARTIDA");start.setTextSize(18);content.addView(start);start.setOnClickListener(v->{if(!folderReady||sampledTracks.isEmpty()){toast("Primero elige una carpeta con archivos de audio.");return;}beginGame();});
    content.addView(text("Se incluirán archivos de las subcarpetas. El número elegido debe ser múltiplo del número de jugadores.",12,0xff64748b,false));
  }
  void editPlayers(){
    EditText input=new EditText(this);input.setHint("Nombres separados por comas");input.setText(String.join(", ",players));
    new AlertDialog.Builder(this).setTitle("Jugadores y orden de turno").setView(input).setPositiveButton("Guardar",(d,w)->{
      ArrayList<String> next=new ArrayList<>();for(String n:input.getText().toString().split(",")){n=n.trim();if(!n.isEmpty())next.add(n);}
      if(!next.isEmpty()){players.clear();players.addAll(next);scores=new int[players.size()];selectedSongCount=players.size();showSetup();}
    }).setNegativeButton("Cancelar",null).show();
  }
  void pickFolder(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_FOLDER);}
  @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req!=PICK_FOLDER||res!=RESULT_OK||data==null)return;
    folderUri=data.getData();try{getContentResolver().takePersistableUriPermission(folderUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
    infoText.setText("Examinando archivos de la carpeta y subcarpetas…");
    worker.execute(()->{ArrayList<Track> reservoir=new ArrayList<>();int[] count={0};scanFolder(folderUri,reservoir,count);
      for(Track t:reservoir)readMetadata(t);
      runOnUiThread(()->{sampledTracks.clear();sampledTracks.addAll(reservoir);folderReady=!sampledTracks.isEmpty();if(infoText!=null)infoText.setText("Se han encontrado "+sampledTracks.size()+" canciones candidatas. Elige un múltiplo del número de jugadores; la lista permanece oculta.");showSetup();});
    });
  }
  void scanFolder(Uri tree,ArrayList<Track> reservoir,int[] seen){
    try{
      String id=DocumentsContract.getTreeDocumentId(tree);scanDoc(tree,id,reservoir,seen);
    }catch(Exception ignored){}
  }
  void scanDoc(Uri tree,String parent,ArrayList<Track> reservoir,int[] seen){
    Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent);
    String[] cols={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
    try(android.database.Cursor c=getContentResolver().query(children,cols,null,null,null)){
      if(c==null)return;while(c.moveToNext()){
        String id=c.getString(0),name=c.getString(1),mime=c.getString(2);
        if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){scanDoc(tree,id,reservoir,seen);continue;}
        if(mime!=null&&mime.startsWith("audio/")){
          seen[0]++;Track t=new Track();t.uri=DocumentsContract.buildDocumentUriUsingTree(tree,id);t.fileName=name==null?"Audio":name;
          if(reservoir.size()<selectedSongCount)reservoir.add(t);else{int slot=new Random().nextInt(seen[0]);if(slot<selectedSongCount)reservoir.set(slot,t);}
        }
      }
    }catch(Exception ignored){}
  }
  void readMetadata(Track t){
    MediaMetadataRetriever r=new MediaMetadataRetriever();try{r.setDataSource(this,t.uri);
      String title=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),artist=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),dur=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
      t.title=(title==null||title.trim().isEmpty())?t.fileName.replaceFirst("\\.[^.]+$",""):title;
      t.artist=(artist==null||artist.trim().isEmpty())?"Artista no identificado":artist;
      try{t.durationMs=dur==null?0:Long.parseLong(dur);}catch(Exception ignored){}
    }catch(Exception e){t.title=t.fileName.replaceFirst("\\.[^.]+$","");t.artist="Artista no identificado";}finally{try{r.release();}catch(Exception ignored){}}
  }
  void beginGame(){
    if(players.size()<2){toast("La partida necesita al menos 2 jugadores: uno arbitra y otro adivina.");showSetup();return;}
    gameStarted=true;songIndex=0;round=0;refereeIndex=0;playerIndex=nextContestant(refereeIndex);scores=new int[players.size()];titleSolved=false;artistSolved=false;round3Start=0;roundOneStarted=false;loadClues(sampledTracks.get(songIndex));showRound();
  }
  int nextContestant(int referee){return (referee+1)%players.size();}
  int contestantCount(){return Math.max(0,players.size()-1);}
  void loadClues(Track t){
    // Best-effort online lookups run in background; the referee can edit/replace clues if unavailable.
    worker.execute(()->{String lyric="",translation="";
      try{String artist=URLEncoder.encode(t.artist,"UTF-8"),title=URLEncoder.encode(t.title,"UTF-8");
        HttpURLConnection c=(HttpURLConnection)new URL("https://api.lyrics.ovh/v1/"+artist+"/"+title).openConnection();c.setConnectTimeout(4500);c.setReadTimeout(4500);
        if(c.getResponseCode()==200){BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder b=new StringBuilder();String line;while((line=br.readLine())!=null)b.append(line);String lyrics=new JSONObject(b.toString()).optString("lyrics","");String[] lines=lyrics.split("\\R");ArrayList<String> usable=new ArrayList<>();for(String s:lines)if(s.trim().split("\\s+").length>=5&&s.trim().length()<150)usable.add(s.trim());if(!usable.isEmpty())lyric=usable.get(new Random().nextInt(usable.size()));}c.disconnect();
      }catch(Exception ignored){}
      try{String q=URLEncoder.encode(t.title,"UTF-8");HttpURLConnection c=(HttpURLConnection)new URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=es&dt=t&q="+q).openConnection();c.setConnectTimeout(4500);c.setReadTimeout(4500);if(c.getResponseCode()==200){BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder b=new StringBuilder();String line;while((line=br.readLine())!=null)b.append(line);JSONArray chunks=new JSONArray(b.toString()).getJSONArray(0);StringBuilder tr=new StringBuilder();for(int i=0;i<chunks.length();i++)tr.append(chunks.getJSONArray(i).optString(0));translation=tr.toString();}c.disconnect();}catch(Exception ignored){}
      final String l=lyric,es=translation;runOnUiThread(()->{t.lyricClue=l;t.spanishClue=es;if(gameStarted&&sampledTracks.get(songIndex)==t)refreshClue();});
    });
  }
  int[] bg={0xffeaf2ff,0xffe8f7f1,0xfffff0df,0xfff5eaff};
  String[] roundNames={"FRAGMENTO MUSICAL","FRASE DE LA LETRA","SEGUNDO FRAGMENTO MUSICAL","TÍTULO EN ESPAÑOL"};
  void showRound(){
    stopTimer();stopAudio();
    if(round==2&&round3Start==0)round3Start=randomSecondStart(sampledTracks.get(songIndex));
    if(songIndex>=sampledTracks.size()){showEnd();return;}
    Track t=sampledTracks.get(songIndex);base(bg[round]);
    content.addView(text("CANCIÓN "+(songIndex+1)+" DE "+sampledTracks.size(),13,0xff475569,true));
    content.addView(text("RONDA "+(round+1)+"/4 · "+roundNames[round],22,0xff172554,true));
    content.addView(text("ÁRBITRO: "+players.get(refereeIndex)+"  |  "+t.title+" — "+t.artist,15,0xff334155,true));
    content.addView(text("Concursan: "+contestantsLabel(),13,0xff475569,false));
    refereeClueText=text("Pista para el árbitro: "+clueForRound(t),16,0xff1f2937,false);content.addView(refereeClueText);
    Button edit=button("Editar / sustituir pista del árbitro");content.addView(edit);edit.setOnClickListener(v->editClues(t));
    if(round==0){
      Button change=button("↻ CAMBIAR CANCIÓN (si el inicio está en silencio)");content.addView(change);change.setEnabled(!roundOneStarted);change.setOnClickListener(v->changeCurrentSong());
    }
    if(round==0||round==2){
      Button audio=button(round==0?"▶ REPRODUCIR FRAGMENTO INICIAL":"▶ REPRODUCIR SEGUNDO FRAGMENTO");content.addView(audio);
      final long clipStart=round==0?0:round3Start;
      audio.setOnClickListener(v->playClip(clipStart,7000));
    } else {
      content.addView(text(round==1?"Lee la frase de la letra al jugador":"Lee la traducción o paráfrasis al jugador",13,0xff475569,false));
    }
    content.addView(text("Turno: "+players.get(playerIndex),20,0xff172554,true));
    timerText=text("15",42,0xff172554,true);timerText.setGravity(Gravity.CENTER);content.addView(timerText);
    startTurnButton=button("INICIAR TURNO · 15 SEGUNDOS");startTurnButton.setTextSize(17);content.addView(startTurnButton);startTurnButton.setOnClickListener(v->startTimer());
    content.addView(text("PUNTUAR A "+players.get(playerIndex)+" (concursante)",14,0xff334155,true));
    int songPts=new int[]{8,6,4,2}[round], artistPts=new int[]{4,3,2,1}[round];
    LinearLayout points=new LinearLayout(this);points.setOrientation(LinearLayout.VERTICAL);content.addView(points);
    Button songButton=button(titleSolved?"✓ TÍTULO YA ADIVINADO":"ACERTÓ TÍTULO · +"+songPts);points.addView(songButton);songButton.setEnabled(!titleSolved);
    songButton.setOnClickListener(v->{if(!titleSolved){titleSolved=true;scores[playerIndex]+=songPts;refreshScoreboard();songButton.setText("✓ TÍTULO YA ADIVINADO");songButton.setEnabled(false);if(artistSolved){toast("Título y artista resueltos. Pasamos a la siguiente canción.");nextSong();}}});
    Button artistButton=button(artistSolved?"✓ ARTISTA YA ADIVINADO":"ACERTÓ ARTISTA · +"+artistPts);points.addView(artistButton);artistButton.setEnabled(!artistSolved);
    artistButton.setOnClickListener(v->{if(!artistSolved){artistSolved=true;scores[playerIndex]+=artistPts;refreshScoreboard();artistButton.setText("✓ ARTISTA YA ADIVINADO");artistButton.setEnabled(false);if(titleSolved){toast("Título y artista resueltos. Pasamos a la siguiente canción.");nextSong();}}});
    scoreboardText=text(scoreboard(),15,0xff172554,true);content.addView(scoreboardText);
    nextButton=button("SIGUIENTE JUGADOR");content.addView(nextButton);nextButton.setOnClickListener(v->advancePlayer());
    Button nextSong=button("TERMINAR CANCIÓN / SIGUIENTE CANCIÓN");content.addView(nextSong);nextSong.setOnClickListener(v->nextSong());
    content.addView(text("El árbitro no concursa en esta canción. Los demás juegan esta ronda por turnos; al acabar, se pasa a la ronda siguiente. El árbitro rota en cada canción.",12,0xff64748b,false));
  }
  void changeCurrentSong(){
    if(round!=0||roundOneStarted||titleSolved||artistSolved){toast("La canción solo se puede cambiar antes de empezar la ronda 1.");return;}
    if(folderUri==null){toast("No se encuentra la carpeta de música.");return;}
    base(0xffeaf2ff);content.addView(text("Buscando otra canción…",18,0xff172554,true));
    worker.execute(()->{
      ArrayList<Track> all=new ArrayList<>();collectAllAudio(folderUri,DocumentsContract.getTreeDocumentId(folderUri),all);
      HashSet<String> already=new HashSet<>();for(int i=0;i<songIndex;i++)already.add(sampledTracks.get(i).uri.toString());
      for(int i=songIndex+1;i<sampledTracks.size();i++)already.add(sampledTracks.get(i).uri.toString());
      already.add(sampledTracks.get(songIndex).uri.toString());
      ArrayList<Track> choices=new ArrayList<>();for(Track candidate:all)if(!already.contains(candidate.uri.toString()))choices.add(candidate);
      if(choices.isEmpty()){runOnUiThread(()->{toast("No hay otra canción disponible en esa carpeta que no esté ya seleccionada.");showRound();});return;}
      Track replacement=choices.get(new Random().nextInt(choices.size()));readMetadata(replacement);
      runOnUiThread(()->{stopAudio();sampledTracks.set(songIndex,replacement);titleSolved=false;artistSolved=false;round3Start=0;roundOneStarted=false;loadClues(replacement);showRound();toast("Canción sustituida. La descartada no se repetirá en esta partida.");});
    });
  }
  void collectAllAudio(Uri tree,String parent,ArrayList<Track> out){
    Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent);
    String[] cols={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
    try(android.database.Cursor c=getContentResolver().query(children,cols,null,null,null)){
      if(c==null)return;while(c.moveToNext()){String id=c.getString(0),name=c.getString(1),mime=c.getString(2);
        if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){collectAllAudio(tree,id,out);continue;}
        if(mime!=null&&mime.startsWith("audio/")){Track t=new Track();t.uri=DocumentsContract.buildDocumentUriUsingTree(tree,id);t.fileName=name==null?"Audio":name;out.add(t);}
      }
    }catch(Exception ignored){}
  }
  String contestantsLabel(){StringBuilder b=new StringBuilder();for(int i=0;i<players.size();i++)if(i!=refereeIndex){if(b.length()>0)b.append(" · ");b.append(players.get(i));}return b.toString();}
  String clueForRound(Track t){switch(round){case 1:return t.lyricClue.isEmpty()?"Letra no encontrada automáticamente; el árbitro puede introducir una frase.":t.lyricClue;case 3:return t.spanishClue.isEmpty()?"Traducción no disponible; el árbitro puede escribir una paráfrasis.":t.spanishClue;default:return "Respuesta correcta: "+t.title+" — "+t.artist;}}
  void refreshClue(){if(refereeClueText!=null)refereeClueText.setText("Pista para el árbitro: "+clueForRound(sampledTracks.get(songIndex)));}
  void editClues(Track t){LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);EditText lyric=new EditText(this);lyric.setHint("Frase de letra para ronda 2");lyric.setText(t.lyricClue);form.addView(lyric);EditText spanish=new EditText(this);spanish.setHint("Traducción/paráfrasis para ronda 4");spanish.setText(t.spanishClue);form.addView(spanish);new AlertDialog.Builder(this).setTitle("Pistas del árbitro").setView(form).setPositiveButton("Guardar",(d,w)->{t.lyricClue=lyric.getText().toString().trim();t.spanishClue=spanish.getText().toString().trim();refreshClue();}).setNegativeButton("Cancelar",null).show();}
  void startTimer(){if(turnActive)return;if(round==0)roundOneStarted=true;turnActive=true;timerExpired=false;secondsLeft=TURN_SECONDS;if(startTurnButton!=null)startTurnButton.setEnabled(false);
    String who=players.get(playerIndex);if(tts!=null){tts.speak(who,TextToSpeech.QUEUE_FLUSH,null,"player_name");handler.postDelayed(()->{if(turnActive&&tts!=null){tts.speak("Ya",TextToSpeech.QUEUE_FLUSH,null,"ready");handler.postDelayed(()->{if(turnActive)tick();},350);}},850);}else{toast(who+"… ¡Ya!");tick();}
  }
  void tick(){if(timerText!=null)timerText.setText(String.valueOf(secondsLeft));if(secondsLeft<=0){turnActive=false;timerExpired=true;if(tts!=null)tts.speak("Tiempo",TextToSpeech.QUEUE_FLUSH,null,null);if(startTurnButton!=null)startTurnButton.setEnabled(true);return;}secondsLeft--;timerRunnable=()->tick();handler.postDelayed(timerRunnable,1000);}
  void stopTimer(){if(timerRunnable!=null)handler.removeCallbacks(timerRunnable);timerRunnable=null;turnActive=false;}
  void advancePlayer(){
    stopTimer();stopAudio();if(titleSolved&&artistSolved){nextSong();return;}
    int next=(playerIndex+1)%players.size();
    if(next!=refereeIndex){playerIndex=next;showRound();return;}
    // Ya han participado todos los concursantes en esta ronda.
    if(round+1<ROUNDS){round++;playerIndex=nextContestant(refereeIndex);if(round==2)round3Start=randomSecondStart(sampledTracks.get(songIndex));showRound();return;}
    nextSong();
  }
  void nextSong(){
    stopTimer();stopAudio();songIndex++;round=0;titleSolved=false;artistSolved=false;round3Start=0;
    if(songIndex<sampledTracks.size()){
      // El árbitro rota: canción 1 -> jugador 1, canción 2 -> jugador 2, etc.
      refereeIndex=songIndex%players.size();playerIndex=nextContestant(refereeIndex);
      roundOneStarted=false;loadClues(sampledTracks.get(songIndex));showRound();
    }else showEnd();
  }
  void playClip(long start,long length){Track t=sampledTracks.get(songIndex);stopAudio();try{player=new MediaPlayer();player.setDataSource(this,t.uri);player.setOnPreparedListener(mp->{try{mp.seekTo((int)Math.max(0,start));mp.start();handler.postDelayed(()->stopAudio(),length);}catch(Exception ignored){stopAudio();}});player.setOnErrorListener((mp,w,e)->{stopAudio();toast("No se pudo reproducir ese archivo.");return true;});player.prepareAsync();}catch(Exception e){toast("Error al abrir el audio.");}}
  long randomSecondStart(Track t){if(t.durationMs<=8000)return 0;long max=t.durationMs-7000;return (long)(Math.random()*max);}
  void stopAudio(){if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}}
  String scoreboard(){StringBuilder s=new StringBuilder("MARCADOR ACUMULADO\n");for(int i=0;i<players.size();i++)s.append(players.get(i)).append(" · ").append(scores[i]).append(" puntos\n");return s.toString();}
  void refreshScoreboard(){if(scoreboardText!=null)scoreboardText.setText(scoreboard());}
  void showEnd(){stopTimer();stopAudio();gameStarted=false;base(0xffeaf2ff);content.addView(text("¡PARTIDA TERMINADA!",26,0xff172554,true));content.addView(text(scoreboard(),19,0xff172554,true));
    Button rescan=button("NUEVA PARTIDA · MISMA CARPETA, 10 CANCIONES NUEVAS");content.addView(rescan);rescan.setEnabled(folderUri!=null);rescan.setOnClickListener(v->rescanCurrentFolder());
    Button setup=button("CAMBIAR CARPETA / JUGADORES");content.addView(setup);setup.setOnClickListener(v->{sampledTracks.clear();folderReady=false;showSetup();});}
  void rescanCurrentFolder(){if(folderUri==null){showSetup();return;}base(0xfff3f5fa);content.addView(text("Sorteando una nueva selección…",18,0xff18233b,true));worker.execute(()->{ArrayList<Track> reservoir=new ArrayList<>();int[] count={0};scanFolder(folderUri,reservoir,count);for(Track t:reservoir)readMetadata(t);runOnUiThread(()->{sampledTracks.clear();sampledTracks.addAll(reservoir);folderReady=!sampledTracks.isEmpty();if(folderReady){scores=new int[players.size()];beginGame();}else{toast("No se encontraron archivos de audio.");showSetup();}});});}
  void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
  @Override protected void onDestroy(){stopTimer();stopAudio();worker.shutdownNow();if(tts!=null)tts.shutdown();super.onDestroy();}
}
