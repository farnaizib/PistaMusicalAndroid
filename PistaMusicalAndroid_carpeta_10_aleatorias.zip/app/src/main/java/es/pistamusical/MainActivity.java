package es.pistamusical;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.widget.*;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
  static final int REQ_M3U=21, REQ_AUDIO=11, REQ_FOLDER=31;
  static class Track {
    String path="", title="", artist="", lyricHint="", titleHint="";
    Uri uri; boolean used, titleGuessed, artistGuessed;
  }
  ArrayList<Track> tracks=new ArrayList<>();
  ArrayList<Track> gameTracks=new ArrayList<>();
  ArrayList<String> players=new ArrayList<>(Arrays.asList("Jugador 1","Jugador 2"));
  int[] scores=new int[12];
  int playerIndex=0, round=0, seconds=15, audioSeen=0;
  Track current;
  MediaPlayer media;
  TextToSpeech tts;
  Handler handler=new Handler();
  Runnable tick;
  TextView status, roundLabel, timerLabel, clue, scoreboard;
  LinearLayout rootView;
  Button turnButton, titleButton, artistButton, nextSongButton, hintsButton, answerButton, googleLyricsButton, translateTitleButton, synonymButton;
  boolean gameStarted=false, timerRunning=false, previewing=false;

  @Override public void onCreate(Bundle b){
    super.onCreate(b);
    tts=new TextToSpeech(this, status->{ if(status==TextToSpeech.SUCCESS) tts.setLanguage(Locale("es","ES")); });
    buildUi();
    requestAudioPermission();
  }
  Locale Locale(String lang,String country){return new Locale(lang,country);}
  void buildUi(){
    ScrollView scroll=new ScrollView(this);
    LinearLayout root=new LinearLayout(this); rootView=root; root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,20,24,28); root.setBackgroundColor(0xff18233b); scroll.addView(root);
    LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER); brand.setOrientation(LinearLayout.VERTICAL); brand.setPadding(12,14,12,18); brand.setBackgroundColor(0xff243653); root.addView(brand);
    TextView logo=new TextView(this); logo.setText("♫  🎧  ♫"); logo.setTextSize(30); logo.setGravity(Gravity.CENTER); logo.setTextColor(0xffffd166); brand.addView(logo);
    TextView heading=new TextView(this); heading.setText("PISTA MUSICAL"); heading.setTextSize(25); heading.setTextColor(-1); heading.setGravity(Gravity.CENTER); heading.setTypeface(null,1); brand.addView(heading);
    TextView tagline=new TextView(this); tagline.setText("Adivina la canción · ¡Que suene la música!"); tagline.setTextSize(13); tagline.setTextColor(0xffd9e5f7); tagline.setGravity(Gravity.CENTER); brand.addView(tagline);
    Button setup=new Button(this); setup.setText("Configurar jugadores"); root.addView(setup); setup.setOnClickListener(v->setupPlayers());
    Button importBtn=new Button(this); importBtn.setText("Importar playlist M3U de Pulsar"); root.addView(importBtn); importBtn.setOnClickListener(v->pickM3u());
    Button scan=new Button(this); scan.setText("Elegir carpeta de música (incluye subcarpetas)"); root.addView(scan); scan.setOnClickListener(v->pickMusicFolder());
    status=label(root,"Importa la playlist M3U y configura los jugadores.");
    roundLabel=label(root,"Ronda —");
    clue=label(root,"La pista y la respuesta aparecerán aquí.");
    timerLabel=label(root,"15 s"); timerLabel.setTextSize(26); timerLabel.setGravity(Gravity.CENTER);
    googleLyricsButton=new Button(this); googleLyricsButton.setText("Buscar letra en Google (título + artista)"); root.addView(googleLyricsButton); googleLyricsButton.setOnClickListener(v->googleLyrics());
    translateTitleButton=new Button(this); translateTitleButton.setText("Traducir título inglés → español"); root.addView(translateTitleButton); translateTitleButton.setOnClickListener(v->translateTitle());
    synonymButton=new Button(this); synonymButton.setText("Buscar paráfrasis/sinónimo del título en español"); root.addView(synonymButton); synonymButton.setOnClickListener(v->searchTitleParaphrase());
    hintsButton=new Button(this); hintsButton.setText("Editar pistas para esta canción"); root.addView(hintsButton); hintsButton.setOnClickListener(v->editHints());
    answerButton=new Button(this); answerButton.setText("Mostrar respuesta al árbitro"); root.addView(answerButton); answerButton.setOnClickListener(v->{if(current!=null)clue.setText("Respuesta del árbitro: "+current.title+" — "+current.artist);});
    turnButton=new Button(this); turnButton.setText("Empezar partida / siguiente canción"); root.addView(turnButton); turnButton.setOnClickListener(v->startOrNextSong());
    Button startTurn=new Button(this); startTurn.setText("Dar paso al jugador (nombre · Ya)"); root.addView(startTurn); startTurn.setOnClickListener(v->beginPlayerTurn());
    LinearLayout marks=new LinearLayout(this); root.addView(marks);
    titleButton=new Button(this); titleButton.setText("Título acertado"); marks.addView(titleButton,new LinearLayout.LayoutParams(0,-2,1)); titleButton.setOnClickListener(v->markTitle());
    artistButton=new Button(this); artistButton.setText("Artista acertado"); marks.addView(artistButton,new LinearLayout.LayoutParams(0,-2,1)); artistButton.setOnClickListener(v->markArtist());
    Button timeEnd=new Button(this); timeEnd.setText("Terminar turno / siguiente jugador"); root.addView(timeEnd); timeEnd.setOnClickListener(v->endTurn());
    nextSongButton=new Button(this); nextSongButton.setText("Saltar canción"); root.addView(nextSongButton); nextSongButton.setOnClickListener(v->startOrNextSong());
    scoreboard=label(root,"Marcador"); setContentView(scroll); updateScoreboard();
  }
  TextView label(LinearLayout parent,String text){TextView t=new TextView(this);t.setText(text);t.setTextColor(0xfff1f5f9);t.setTextSize(17);t.setPadding(0,12,0,12);parent.addView(t);return t;}
  void setupPlayers(){
    EditText e=new EditText(this);e.setHint("Nombres separados por comas");e.setText(String.join(", ",players));
    new AlertDialog.Builder(this).setTitle("Jugadores").setMessage("Introduce los nombres en el orden de juego").setView(e).setPositiveButton("Guardar",(d,w)->{
      ArrayList<String> names=new ArrayList<>();for(String s:e.getText().toString().split(",")){s=s.trim();if(!s.isEmpty())names.add(s);}
      if(names.size()>0){players=names;scores=new int[Math.max(12,names.size())];playerIndex=0;updateScoreboard();status.setText("Jugadores: "+String.join(", ",players));}
    }).setNegativeButton("Cancelar",null).show();
  }
  void searchTitleParaphrase(){
    if(current==null){status.setText("Selecciona una canción primero.");return;}
    try{
      String q=current.title+" significado expresión equivalente sinónimo";
      Uri search=Uri.parse("https://www.google.com/search?q="+java.net.URLEncoder.encode(q,"UTF-8"));
      startActivity(new Intent(Intent.ACTION_VIEW,search));
      status.setText("Busca una expresión equivalente, no el título literal. El árbitro puede anotarla en «Editar pistas» para la ronda 4.");
    }catch(Exception ex){status.setText("No se pudo abrir la búsqueda: "+ex.getMessage());}
  }
  void translateTitle(){
    if(current==null){status.setText("Selecciona una canción primero.");return;}
    try{
      String encoded=java.net.URLEncoder.encode(current.title,"UTF-8");
      Uri translate=Uri.parse("https://translate.google.com/?sl=en&tl=es&text="+encoded+"&op=translate");
      startActivity(new Intent(Intent.ACTION_VIEW,translate));
      status.setText("Google Translate abierto con el título en inglés. Copia la traducción y anótala en «Editar pistas» para la ronda 4.");
    }catch(Exception ex){status.setText("No se pudo abrir Google Translate: "+ex.getMessage());}
  }
  void googleLyrics(){
    if(current==null){status.setText("Selecciona una canción primero.");return;}
    String q=current.title+" "+current.artist+" letra canción";
    try{
      Uri search=Uri.parse("https://www.google.com/search?q="+java.net.URLEncoder.encode(q,"UTF-8"));
      Intent i=new Intent(Intent.ACTION_VIEW,search);startActivity(i);
      status.setText("Google abierto. Busca una frase adecuada, vuelve a Pista Musical y pulsa «Editar pistas» para anotarla.");
    }catch(Exception ex){status.setText("No se pudo abrir Google: "+ex.getMessage());}
  }
  void editHints(){
    if(current==null){status.setText("Selecciona una canción primero.");return;}
    LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(20,4,20,4);
    EditText lyric=new EditText(this);lyric.setHint("Frase de la letra para ronda 2");lyric.setMinLines(2);lyric.setText(current.lyricHint);form.addView(lyric);
    EditText titleHint=new EditText(this);titleHint.setHint("Traducción o sinónimo del título para ronda 4");titleHint.setMinLines(2);titleHint.setText(current.titleHint);form.addView(titleHint);
    new AlertDialog.Builder(this).setTitle("Pistas de esta canción").setView(form).setPositiveButton("Guardar",(d,w)->{current.lyricHint=lyric.getText().toString().trim();current.titleHint=titleHint.getText().toString().trim();status.setText("Pistas guardadas para esta canción.");}).setNegativeButton("Cancelar",null).show();
  }
  void pickMusicFolder(){
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
    startActivityForResult(i,REQ_FOLDER);
  }
  void scanChosenFolder(Uri treeUri){
    try{
      getContentResolver().takePersistableUriPermission(treeUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
      tracks.clear(); audioSeen=0;
      Uri root=android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri,android.provider.DocumentsContract.getTreeDocumentId(treeUri));
      scanDocumentFolder(treeUri,root);
      // Quitar duplicados por URI y conservar solo audio reproducible.
      LinkedHashMap<String,Track> unique=new LinkedHashMap<>();
      for(Track t:tracks)if(t.uri!=null)unique.put(t.uri.toString(),t);
      tracks=new ArrayList<>(unique.values());
      for(Track t:tracks)t.used=false;
      status.setText("Carpeta explorada (incluidas subcarpetas): "+audioSeen+" archivos. Se han elegido al azar hasta 10; solo esos se usarán en la partida.");
    }catch(Exception ex){status.setText("No se pudo leer la carpeta: "+ex.getMessage());}
  }
  void scanDocumentFolder(Uri tree,Uri folder){
    String id=android.provider.DocumentsContract.getDocumentId(folder);
    Uri children=android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree,id);
    String[] cols={android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE};
    try(Cursor c=getContentResolver().query(children,cols,null,null,null)){
      if(c==null)return;
      while(c.moveToNext()){
        String docId=c.getString(0),name=c.getString(1),mime=c.getString(2);
        Uri doc=android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,docId);
        if(android.provider.DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){scanDocumentFolder(tree,doc);continue;}
        if(mime!=null&&mime.startsWith("audio/")){
          // Reservoir sampling: recorrer los nombres/metadatos, pero conservar solo 10 candidatos.
          audioSeen++;
          Track t=new Track();t.uri=doc;t.path=name==null?"":name;
          String n=t.path; t.title=n.replaceFirst("\\.[^.]+$",""); t.artist="";
          if(tracks.size()<10) tracks.add(t);
          else { int slot=new Random().nextInt(audioSeen); if(slot<10) tracks.set(slot,t); }
        }
      }
    }catch(Exception ignored){}
  }
  void requestAudioPermission(){
    String perm=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE;
    if(checkSelfPermission(perm)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{perm},REQ_AUDIO);
  }
  @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_AUDIO&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)scanLibrary();}
  void pickM3u(){
    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
    i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"audio/x-mpegurl","application/octet-stream","text/plain"});startActivityForResult(i,REQ_M3U);
  }
  @Override protected void onActivityResult(int r,int res,Intent data){
    super.onActivityResult(r,res,data);if(res!=RESULT_OK||data==null)return;if(r==REQ_FOLDER){scanChosenFolder(data.getData());return;}if(r!=REQ_M3U)return;
    try(InputStream in=getContentResolver().openInputStream(data.getData());BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){
      tracks.clear();String line;while((line=br.readLine())!=null){line=line.trim();if(line.isEmpty()||line.startsWith("#"))continue;
        Track t=new Track();t.path=line;String[] parts=line.split("[/\\\\]");String fn=parts[parts.length-1];
        t.title=fn.replaceFirst("\\.[^.]+$","").replaceFirst("^\\d+[- ._]","");
        t.artist=parts.length>=3?parts[parts.length-3]:"";tracks.add(t);
      }
      status.setText("Playlist cargada: "+tracks.size()+" canciones. Localizando archivos…");scanLibrary();
    }catch(Exception ex){status.setText("No se pudo leer la playlist: "+ex.getMessage());}
  }
  void scanLibrary(){
    String perm=Build.VERSION.SDK_INT>=33?Manifest.permission.READ_MEDIA_AUDIO:Manifest.permission.READ_EXTERNAL_STORAGE;
    if(checkSelfPermission(perm)!=PackageManager.PERMISSION_GRANTED){requestAudioPermission();return;}
    HashMap<String,Track> indexed=new HashMap<>();
    String[] cols={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.DISPLAY_NAME,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST};
    try(Cursor c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,cols,null,null,null)){
      if(c!=null)while(c.moveToNext()){
        long id=c.getLong(0);String display=c.getString(1),title=c.getString(2),artist=c.getString(3);
        Track t=new Track();t.uri=ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id);
        t.title=title==null?"":title;t.artist=artist==null?"":artist;
        indexed.put(display==null?"":display.toLowerCase(Locale.ROOT),t);
      }
    }catch(Exception ex){status.setText("Error accediendo a música: "+ex.getMessage());return;}
    int found=0;
    for(Track t:tracks){String fn=t.path.substring(Math.max(t.path.lastIndexOf('/'),t.path.lastIndexOf('\\'))+1).toLowerCase(Locale.ROOT);
      Track m=indexed.get(fn);if(m!=null){t.uri=m.uri;if(!m.title.isEmpty())t.title=m.title;if(!m.artist.isEmpty())t.artist=m.artist;found++;}}
    status.setText(tracks.size()+" canciones en playlist · "+found+" archivos encontrados. La lista se barajará sin repetir.");
  }
  void startOrNextSong(){
    stopTimer();stopMedia();
    if(tracks.isEmpty()){status.setText("Primero elige una carpeta de música.");return;}
    if(!gameStarted){gameTracks=new ArrayList<>();for(Track t:tracks)if(t.uri!=null)gameTracks.add(t);Collections.shuffle(gameTracks);if(gameTracks.size()>10)gameTracks=new ArrayList<>(gameTracks.subList(0,10));for(Track t:gameTracks)t.used=false;}
    ArrayList<Track> unused=new ArrayList<>();for(Track t:gameTracks)if(t.uri!=null&&!t.used)unused.add(t);
    if(unused.isEmpty()){gameStarted=false;current=null;clue.setText("Fin de partida: se han agotado las canciones localizadas.");status.setText("Partida terminada. No se repitió ninguna canción.");roundLabel.setText("Fin de partida");return;}
    current=unused.get(new Random().nextInt(unused.size()));current.used=true;current.titleGuessed=false;current.artistGuessed=false;round=1;playerIndex=0;gameStarted=true;
    roundLabel.setText("Canción nueva · Ronda 1/4 · jugador "+players.get(playerIndex));
    clue.setText("ÁRBITRO · Respuesta: "+current.title+" — "+current.artist+"\nPrueba 1: escucha el fragmento e identifica título y artista."); applyRoundTheme();
    sayWithId("Música","intro_music_"+System.currentTimeMillis());status.setText("Reproduciendo fragmento inicial (7 s).");playSegment(0,7000);
  }
  void playSegment(int startMs,int lengthMs){
    stopMedia();if(current==null||current.uri==null)return;
    try{media=new MediaPlayer();media.setDataSource(this,current.uri);media.setOnErrorListener((mp,what,extra)->{status.setText("Error al reproducir el audio (código "+what+"/"+extra+").");stopMedia();return true;});media.setOnPreparedListener(mp->{try{mp.seekTo(startMs);mp.start();handler.postDelayed(()->stopMedia(),lengthMs);}catch(Exception ex){status.setText("No se pudo iniciar el audio: "+ex.getMessage());stopMedia();}});media.prepareAsync();}
    catch(Exception ex){status.setText("No se pudo reproducir: "+ex.getMessage());}
  }
  void stopMedia(){if(media!=null){try{media.stop();}catch(Exception ignored){}media.release();media=null;}previewing=false;}
  void beginPlayerTurn(){
    if(!gameStarted||current==null){status.setText("Empieza una canción primero.");return;}
    stopTimer();String name=players.get(playerIndex);roundLabel.setText("Ronda "+round+"/4 · turno de "+name);
    String answer="\nÁRBITRO · Respuesta: "+current.title+" — "+current.artist;
    if(round==2)clue.setText("PRUEBA 2 · FRASE DE LA LETRA\nPista: "+(current.lyricHint.isEmpty()?"[sin frase preparada; puede editarse en Pistas]":current.lyricHint)+answer);
    else if(round==4)clue.setText("PRUEBA 4 · TÍTULO EN ESPAÑOL\nPista: "+(current.titleHint.isEmpty()?"[sin traducción/paráfrasis preparada]":current.titleHint)+answer);
    else if(round==3)clue.setText("PRUEBA 3 · SEGUNDO FRAGMENTO MUSICAL"+answer);
    else clue.setText("PRUEBA 1 · FRAGMENTO MUSICAL"+answer);
    applyRoundTheme();
    sayWithId(name,"player_name_"+System.currentTimeMillis());
  }
  void startTimer(){
    stopTimer();seconds=15;timerLabel.setText("15 s");timerRunning=true;
    tick=new Runnable(){int left=15;public void run(){timerLabel.setText(left+" s");if(left<=0){timerRunning=false;say("Tiempo");return;}left--;handler.postDelayed(this,1000);}};
    handler.post(tick);
  }
  void stopTimer(){if(tick!=null)handler.removeCallbacks(tick);tick=null;timerRunning=false;}
  void endTurn(){
    stopTimer();if(!gameStarted)return;
    if(current.titleGuessed&&current.artistGuessed){finishCurrent();return;}
    playerIndex++;
    if(playerIndex>=players.size()){
      playerIndex=0;round++;
      if(round>4){finishCurrent();return;}
      if(round==3){roundLabel.setText("Ronda 3/4 · Música: fragmento distinto");sayWithId("Música","round3_music_"+System.currentTimeMillis());int duration=estimatedDuration();int start=duration>9000?new Random().nextInt(Math.max(1,duration-7000)):0;playSegment(start,7000);}
      else if(round==2){roundLabel.setText("Ronda 2/4 · pista de letra");}
      else if(round==4){roundLabel.setText("Ronda 4/4 · pista del título");}
    }
    roundLabel.setText("PRUEBA "+round+" DE 4 · siguiente: "+players.get(playerIndex));applyRoundTheme();status.setText("Pulsa «Dar paso» para el siguiente jugador.");
  }
  void applyRoundTheme(){
    if(rootView==null)return; int[] colors={0xff18233b,0xff173b46,0xff3b2853,0xff4a3020,0xff3b2632};
    rootView.setBackgroundColor(colors[Math.max(0,Math.min(4,round))]);
    if(roundLabel!=null){String[] names={"Preparación","1 · Fragmento musical","2 · Frase de la letra","3 · Segundo fragmento","4 · Título en español"};roundLabel.setText(names[Math.max(0,Math.min(4,round))]);roundLabel.setTextSize(21);roundLabel.setTypeface(null,1);}
  }
  void markTitle(){if(current==null||current.titleGuessed){status.setText("El título ya se puntuó o no hay canción activa.");return;}current.titleGuessed=true;int pts=new int[]{0,8,6,4,2}[round];scores[playerIndex]+=pts;updateScoreboard();status.setText(players.get(playerIndex)+" acertó el título: +"+pts);if(current.artistGuessed)finishCurrent();}
  void markArtist(){if(current==null||current.artistGuessed){status.setText("El artista ya se puntuó o no hay canción activa.");return;}current.artistGuessed=true;int pts=new int[]{0,4,3,2,1}[round];scores[playerIndex]+=pts;updateScoreboard();status.setText(players.get(playerIndex)+" acertó el artista: +"+pts);if(current.titleGuessed)finishCurrent();}
  void finishCurrent(){stopTimer();stopMedia();String answer=current.title+" — "+current.artist;clue.setText("Canción resuelta: "+answer);status.setText("Canción resuelta. Pulsa «siguiente canción» para continuar.");}
  int estimatedDuration(){
    if(current==null||current.uri==null)return 0;
    MediaPlayer probe=null;try{probe=new MediaPlayer();probe.setDataSource(this,current.uri);probe.prepare();return probe.getDuration();}catch(Exception e){return 0;}finally{if(probe!=null)probe.release();}
  }
  void sayWithId(String s,String id){if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,id);}
  void say(String s){sayWithId(s,"pm_"+System.currentTimeMillis());}
  void updateScoreboard(){if(scoreboard==null)return;StringBuilder b=new StringBuilder("Marcador\\n");for(int i=0;i<players.size();i++)b.append(players.get(i)).append(": ").append(scores[i]).append("\\n");scoreboard.setText(b.toString());}
  @Override protected void onDestroy(){super.onDestroy();stopTimer();stopMedia();if(tts!=null)tts.shutdown();}
}
