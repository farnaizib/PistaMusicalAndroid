PISTA MUSICAL ANDROID — avance de prototipo

Este proyecto es código fuente Android (todavía no es un APK instalable).

Implementado en esta versión:
- Configuración de nombres de jugadores.
- Importación M3U de Pulsar y búsqueda de pistas en MediaStore por nombre de archivo.
- Selección aleatoria de canciones no utilizadas (sin repetición en la partida).
- Reproducción del fragmento inicial durante 7 segundos.
- Locución TTS «Música», nombre del jugador y «Ya», y «Tiempo».
- Temporizador de 15 segundos.
- Botón que abre una búsqueda de Google de la letra usando título y artista; el árbitro selecciona una frase y la copia manualmente en el campo de pista.\n- Flujo básico de cuatro rondas y puntuación decreciente: título 8/6/4/2; artista 4/3/2/1.
- Bloqueo de puntos duplicados para título/artista; al acertarse ambos se da por resuelta la canción.
- Marcador individual.

Pendiente antes de considerar la app completa:
- Obtener/generar la pista textual de letra para la ronda 2 y traducción/sinónimo para ronda 4 (en esta versión el árbitro debe proporcionar/leer las pistas; no hay búsqueda web automática).
- Ajustar el fragmento aleatorio de ronda 3 para que se anuncie y se reproduzca exactamente antes de los turnos; probarlo con diferentes duraciones de canciones.
- Revisar la interfaz de arbitraje, persistencia de partida y casos de error/compatibilidad en un teléfono real.
- Compilar y probar el APK. No se ha compilado ni verificado en dispositivo.

Compilación prevista: abrir en Android Studio con Android Gradle Plugin 8.7.3 y generar APK desde Build > Build APK(s).
\nLa búsqueda de Google abre el navegador; la app no extrae automáticamente letras de páginas web. Esto evita depender de páginas cambiantes o bloqueos y permite al árbitro elegir una frase apropiada.\n\n- Botón de Google Translate que abre el título precargado con idioma de origen inglés y destino español; el árbitro puede copiar la traducción en la pista de ronda 4.\n\nLa traducción se consulta externamente en Google Translate; esta versión no la captura automáticamente ni detecta por sí sola el idioma del título.\n\n- Botón para buscar en Google significado/sinónimo/paráfrasis de títulos en español. El árbitro escoge una expresión que no revele literalmente el título y la guarda como pista de ronda 4.\n