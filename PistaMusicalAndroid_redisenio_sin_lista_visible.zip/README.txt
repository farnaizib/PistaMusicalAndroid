PISTA MUSICAL — rediseño del flujo de partida

Incluye: configuración de jugadores y selección de carpeta SAF; muestreo aleatorio de hasta 10 archivos de audio (incluye subcarpetas); cuatro pantallas/temas de ronda; turnos de 15 segundos con aviso hablado; controles de puntuación del árbitro y marcador acumulado; consulta en segundo plano, best-effort, de una frase de letra (lyrics.ovh) y traducción del título (endpoint público de Google Translate), con edición manual por el árbitro si la consulta falla.

La app no abre el navegador para buscar pistas. Los servicios web pueden fallar, no están garantizados ni son APIs oficiales estables. El texto de letra se muestra al árbitro como pista; comprueba que sea apropiado para el juego.

Este ZIP contiene código fuente, no una APK. No se ha podido compilar en este entorno ni probar en el dispositivo; compílalo mediante el workflow de GitHub y revisa cualquier error antes de instalar.
