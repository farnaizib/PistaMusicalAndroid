package es.pistamusical;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.DocumentsContract;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.Normalizer;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
  static final int PICK_FOLDER=31;
  static final int ROUNDS=4, TURN_SECONDS=15;
  int selectedSongCount=4;
  static class Track {
    Uri uri; String fileName="", title="", artist="", lyricClue="", spanishClue=""; long durationMs=0; boolean lyricLookupDone=false;
  }
  final ArrayList<Track> sampledTracks=new ArrayList<>();
  final ArrayList<String> players=new ArrayList<>(Arrays.asList("Jugador 1","Jugador 2"));
  final ArrayList<int[]> scoreHistory=new ArrayList<>();
  final ExecutorService worker=Executors.newSingleThreadExecutor();
  final Handler handler=new Handler();
  TextToSpeech tts;
  MediaPlayer player;
  Runnable timerRunnable;
  int[] scores=new int[2];
  int songIndex=0, round=0, playerIndex=0, refereeIndex=0, secondsLeft=TURN_SECONDS;
  boolean folderReady=false, gameStarted=false, turnActive=false, timerExpired=false, roundOneStarted=false;
  boolean titleSolved=false, artistSolved=false, revealFullSongButton=false;
  long round1Start=-1, round3Start=0;
  Uri folderUri;
  LinearLayout root, content;
  TextView timerText, infoText, scoreboardText, refereeClueText;
  Button startTurnButton, nextButton, lyricSearchButton;

  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    tts=new TextToSpeech(this, result->{ if(result==TextToSpeech.SUCCESS) tts.setLanguage(new Locale("es","ES")); });
    showSetup();
  }

  int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
  TextView text(String value,int size,int color,boolean bold){
    TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(4),dp(7),dp(4),dp(7));
    if(bold)t.setTypeface(null,1);return t;
  }
  Button button(String value){Button b=new Button(this);b.setText(value);return b;}
  void base(int bg){
    ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(12),dp(18),dp(24));root.setBackgroundColor(bg);sc.addView(root);
    LinearLayout logo=new LinearLayout(this);logo.setOrientation(LinearLayout.VERTICAL);logo.setGravity(Gravity.CENTER);logo.setPadding(dp(12),dp(12),dp(12),dp(12));logo.setBackgroundColor(0xff14233b);
    TextView mark=text("♫  PISTA MUSICAL  ♫",24,0xffffd166,true);mark.setGravity(Gravity.CENTER);logo.addView(mark);
    TextView sub=text("EL JUEGO DE ADIVINAR CANCIONES",11,0xffe7eefb,true);sub.setGravity(Gravity.CENTER);logo.addView(sub);root.addView(logo);
    content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,dp(10),0,0);root.addView(content);
    setContentView(sc);
  }
  void showSetup(){
    gameStarted=false;base(0xfff3f5fa);
    content.addView(text("PREPARA LA PARTIDA",23,0xff18233b,true));
    content.addView(text("1 · Jugadores",17,0xff18233b,true));
    Button names=button("Configurar nombres de jugadores");content.addView(names);names.setOnClickListener(v->editPlayers());
    TextView playersLabel=text("Jugadores: "+String.join(" · ",players),14,0xff334155,false);content.addView(playersLabel);
    content.addView(text("2 · Número de canciones (múltiplo de jugadores)",17,0xff18233b,true));
    Spinner songCountSpinner=new Spinner(this); ArrayList<String> songOptions=new ArrayList<>();
    int step=Math.max(2,players.size()); for(int n=step;n<=step*10;n+=step)songOptions.add(String.valueOf(n));
    ArrayAdapter<String> songAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,songOptions);songAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);songCountSpinner.setAdapter(songAdapter);
    int chosen=songOptions.indexOf(String.valueOf(selectedSongCount));if(chosen<0){selectedSongCount=step;chosen=0;}songCountSpinner.setSelection(chosen);
    songCountSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onNothingSelected(AdapterView<?> p){} public void onItemSelected(AdapterView<?> p,View v,int pos,long id){try{selectedSongCount=Integer.parseInt(songOptions.get(pos));}catch(Exception ignored){}}});content.addView(songCountSpinner);
    Button folder=button(folderReady?"Cambiar carpeta de música":"Elegir carpeta de música (incluye subcarpetas)");content.addView(folder);folder.setOnClickListener(v->pickFolder());
    infoText=text(folderReady?"Partida preparada: "+sampledTracks.size()+" canciones. Las canciones siguientes permanecerán ocultas.":"Selecciona una carpeta; se sortearán " + selectedSongCount + " canciones. No se mostrará la lista.",14,0xff334155,false);content.addView(infoText);
    Button start=button("COMENZAR PARTIDA");start.setTextSize(18);content.addView(start);start.setOnClickListener(v->{if(!folderReady||sampledTracks.isEmpty()){toast("Primero elige una carpeta con archivos de audio.");return;}beginGame();});
    content.addView(text("Se incluirán archivos de las subcarpetas. El número elegido debe ser múltiplo del número de jugadores.",12,0xff64748b,false));
  }
  void editPlayers(){
    EditText input=new EditText(this);input.setHint("Nombres separados por comas");input.setText(String.join(", ",players));
    new AlertDialog.Builder(this).setTitle("Jugadores y orden de turno").setView(input).setPositiveButton("Guardar",(d,w)->{
      ArrayList<String> next=new ArrayList<>();for(String n:input.getText().toString().split(",")){n=n.trim();if(!n.isEmpty())next.add(n);}
      if(!next.isEmpty()){players.clear();players.addAll(next);scores=new int[players.size()];selectedSongCount=players.size();showSetup();}
    }).setNegativeButton("Cancelar",null).show();
  }
  void pickFolder(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK_FOLDER);}
  @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req!=PICK_FOLDER||res!=RESULT_OK||data==null)return;
    folderUri=data.getData();try{getContentResolver().takePersistableUriPermission(folderUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
    infoText.setText("Examinando archivos de la carpeta y subcarpetas…");
    worker.execute(()->{ArrayList<Track> reservoir=new ArrayList<>();int[] count={0};scanFolder(folderUri,reservoir,count);
      for(Track t:reservoir)readMetadata(t);
      runOnUiThread(()->{sampledTracks.clear();sampledTracks.addAll(reservoir);folderReady=!sampledTracks.isEmpty();if(infoText!=null)infoText.setText("Se han encontrado "+sampledTracks.size()+" canciones candidatas. Elige un múltiplo del número de jugadores; la lista permanece oculta.");showSetup();});
    });
  }
  void scanFolder(Uri tree,ArrayList<Track> reservoir,int[] seen){
    try{
      String id=DocumentsContract.getTreeDocumentId(tree);scanDoc(tree,id,reservoir,seen);
    }catch(Exception ignored){}
  }
  void scanDoc(Uri tree,String parent,ArrayList<Track> reservoir,int[] seen){
    Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent);
    String[] cols={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
    try(android.database.Cursor c=getContentResolver().query(children,cols,null,null,null)){
      if(c==null)return;while(c.moveToNext()){
        String id=c.getString(0),name=c.getString(1),mime=c.getString(2);
        if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){scanDoc(tree,id,reservoir,seen);continue;}
        if(mime!=null&&mime.startsWith("audio/")){
          seen[0]++;Track t=new Track();t.uri=DocumentsContract.buildDocumentUriUsingTree(tree,id);t.fileName=name==null?"Audio":name;
          if(reservoir.size()<selectedSongCount)reservoir.add(t);else{int slot=new Random().nextInt(seen[0]);if(slot<selectedSongCount)reservoir.set(slot,t);}
        }
      }
    }catch(Exception ignored){}
  }
  void readMetadata(Track t){
    MediaMetadataRetriever r=new MediaMetadataRetriever();try{r.setDataSource(this,t.uri);
      String title=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),artist=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),dur=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
      t.title=(title==null||title.trim().isEmpty())?t.fileName.replaceFirst("\\.[^.]+$",""):title;
      t.artist=(artist==null||artist.trim().isEmpty())?"Artista no identificado":artist;
      try{t.durationMs=dur==null?0:Long.parseLong(dur);}catch(Exception ignored){}
    }catch(Exception e){t.title=t.fileName.replaceFirst("\\.[^.]+$","");t.artist="Artista no identificado";}finally{try{r.release();}catch(Exception ignored){}}
  }
  void beginGame(){
    if(players.size()<2){toast("La partida necesita al menos 2 jugadores: uno arbitra y otro adivina.");showSetup();return;}
    gameStarted=true;songIndex=0;round=0;refereeIndex=0;playerIndex=nextContestant(refereeIndex);scores=new int[players.size()];titleSolved=false;artistSolved=false;round1Start=-1;round3Start=0;revealFullSongButton=false;roundOneStarted=false;loadClues(sampledTracks.get(songIndex));showRound();
  }
  int nextContestant(int referee){return (referee+1)%players.size();}
  int contestantCount(){return Math.max(0,players.size()-1);}
  void loadClues(Track t){
    // Busca una frase de letra en lyrics.ovh y, si no hay resultado, prueba LRCLIB.
    // La traducción usa el endpoint de Google Translate (no oficial) con detección automática.
    worker.execute(()->{String lyric="",translation="";
      String normalizedTitle=t.title.replace('´','\'').replace('’','\'').replace('‘','\'').trim();
      try{
        String artist=URLEncoder.encode(t.artist,"UTF-8").replace("+","%20"),title=URLEncoder.encode(normalizedTitle,"UTF-8").replace("+","%20");
        HttpURLConnection c=(HttpURLConnection)new URL("https://api.lyrics.ovh/v1/"+artist+"/"+title).openConnection();
        c.setConnectTimeout(5000);c.setReadTimeout(5000);
        if(c.getResponseCode()==200){BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));StringBuilder b=new StringBuilder();String line;while((line=br.readLine())!=null)b.append(line);lyric=usableLyricLine(new JSONObject(b.toString()).optString("lyrics",""),t);}
        c.disconnect();
      }catch(Exception ignored){}
      if(lyric.isEmpty())try{
        String query="track_name="+URLEncoder.encode(normalizedTitle,"UTF-8")+"&artist_name="+URLEncoder.encode(t.artist,"UTF-8");
        HttpURLConnection c=(HttpURLConnection)new URL("https://lrclib.net/api/get?"+query).openConnection();
        c.setConnectTimeout(5000);c.setReadTimeout(5000);c.setRequestProperty("User-Agent","PistaMusicalAndroid/1.0");
        if(c.getResponseCode()==200){BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));StringBuilder b=new StringBuilder();String line;while((line=br.readLine())!=null)b.append(line);JSONObject obj=new JSONObject(b.toString());String lyrics=obj.optString("plainLyrics","");if(lyrics.isEmpty())lyrics=obj.optString("syncedLyrics","").replaceAll("\\[[^]]*\\]"," ");lyric=usableLyricLine(lyrics,t);}
        c.disconnect();
      }catch(Exception ignored){}
      try{
        String q=URLEncoder.encode(normalizedTitle,"UTF-8");
        HttpURLConnection c=(HttpURLConnection)new URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=es&dt=t&q="+q).openConnection();
        c.setConnectTimeout(5000);c.setReadTimeout(5000);
        if(c.getResponseCode()==200){BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));StringBuilder b=new StringBuilder();String line;while((line=br.readLine())!=null)b.append(line);JSONArray chunks=new JSONArray(b.toString()).getJSONArray(0);StringBuilder tr=new StringBuilder();for(int i=0;i<chunks.length();i++)tr.append(chunks.getJSONArray(i).optString(0));translation=tr.toString().trim();}
        c.disconnect();
      }catch(Exception ignored){}
      final String l=lyric,es=translation;runOnUiThread(()->{t.lyricClue=l;t.spanishClue=es;t.lyricLookupDone=true;if(gameStarted&&songIndex<sampledTracks.size()&&sampledTracks.get(songIndex)==t)refreshClue();});
    });
  }
  String usableLyricLine(String lyrics,Track track){
    if(lyrics==null||lyrics.trim().isEmpty())return "";
    String[] lines=lyrics.split("\\R");ArrayList<String> usable=new ArrayList<>();
    String titleKey=normalizeForClue(track.title),artistKey=normalizeForClue(track.artist);
    for(String raw:lines){
      String line=raw.replaceAll("\\[[^]]*\\]","").trim();
      String key=normalizeForClue(line);
      // Evita pistas que revelen directamente el título o el artista.
      if(line.split("\\s+").length>=5&&line.length()<150&&!titleKey.isEmpty()&&!key.contains(titleKey)
          &&(artistKey.isEmpty()||!key.contains(artistKey)))usable.add(line);
    }
    return usable.isEmpty()?"":usable.get(new Random().nextInt(usable.size()));
  }
  String normalizeForClue(String value){
    if(value==null)return "";
    String n=Normalizer.normalize(value,Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);
    return n.replaceAll("[^a-z0-9]+"," ").trim().replaceAll("\\s+"," ");
  }
  boolean isUsableManualClue(String phrase,Track track){
    if(phrase==null)return false;
    String line=phrase.trim(),key=normalizeForClue(line),titleKey=normalizeForClue(track.title),artistKey=normalizeForClue(track.artist);
    return line.length()>=8&&line.length()<=180&&!key.isEmpty()
      &&(titleKey.isEmpty()||!key.contains(titleKey))&&(artistKey.isEmpty()||!key.contains(artistKey));
  }
  void openGoogleLyricSearch(Track track){
    try{
      String query="Letra de la canción "+track.title+" de "+track.artist;
      String encoded=URLEncoder.encode(query,"UTF-8");
      startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+encoded)));
    }catch(Exception e){toast("No se pudo abrir Google.");}
  }
  void animateButtonPress(View v){
    v.animate().cancel();v.setScaleX(1f);v.setScaleY(1f);
    v.animate().scaleX(0.84f).scaleY(0.84f).setDuration(85).withEndAction(()->
      v.animate().scaleX(1f).scaleY(1f).setDuration(210).setInterpolator(new OvershootInterpolator(2.2f)).start()
    ).start();
  }
  int[] bg={0xffeaf2ff,0xffe8f7f1,0xfffff0df,0xfff5eaff};
  String[] roundNames={"FRAGMENTO MUSICAL","FRASE DE LA LETRA","SEGUNDO FRAGMENTO MUSICAL","TÍTULO EN ESPAÑOL"};
  void showRound(){
    stopTimer();stopAudio();
    if(songIndex>=sampledTracks.size()){showEnd();return;}
    Track t=sampledTracks.get(songIndex);
    if(round==0&&round1Start<0)round1Start=0;
    if(round==2&&round3Start==0){
      long desired=round1Start+60000L;
      round3Start=(t.durationMs>desired+12000L)?desired:randomClipStart(t,round1Start);
    }
    base(bg[round]);
    content.addView(text("CANCIÓN "+(songIndex+1)+" DE "+sampledTracks.size(),13,0xff475569,true));
    content.addView(text("RONDA "+(round+1)+"/4 · "+roundNames[round],22,0xff172554,true));
    content.addView(text("ÁRBITRO: "+players.get(refereeIndex)+"  |  "+t.title+" — "+t.artist,15,0xff334155,true));
    content.addView(text("Concursan: "+contestantsLabel(),13,0xff475569,false));
    // La pista del árbitro solo se muestra en rondas 2 y 4 y es texto no editable.
    refereeClueText=null;
    lyricSearchButton=null;
    if(round==1||round==3){
      refereeClueText=text("Pista para el árbitro: "+clueForRound(t),16,0xff1f2937,false);
      content.addView(refereeClueText);
      if(round==1){
        lyricSearchButton=button("BUSCAR LETRA");
        lyricSearchButton.setVisibility(t.lyricLookupDone&&t.lyricClue.isEmpty()?View.VISIBLE:View.GONE);
        content.addView(lyricSearchButton);
        lyricSearchButton.setOnClickListener(v->openGoogleLyricSearch(sampledTracks.get(songIndex)));
      }
    }
    if(round==0||round==2){
      Button changeClip=button("↻ CAMBIAR FRAGMENTO");
      content.addView(changeClip);
      changeClip.setOnClickListener(v->{
        animateButtonPress(v);
        long old=(round==0?round1Start:round3Start);
        long fresh=randomClipStart(sampledTracks.get(songIndex),old);
        if(round==0)round1Start=fresh;else round3Start=fresh;
        // Detiene cualquier fragmento anterior y reproduce inmediatamente el nuevo clip.
        playClip(fresh,12000L);
      });
      Button changeSong=button("♫ CAMBIAR CANCIÓN");
      content.addView(changeSong);
      changeSong.setEnabled(!titleSolved&&!artistSolved);
      changeSong.setOnClickListener(v->changeCurrentSong());
      Button audio=button(round==0?"▶ REPRODUCIR FRAGMENTO":"▶ REPRODUCIR FRAGMENTO");
      content.addView(audio);
      final long clipStart=round==0?round1Start:round3Start;
      audio.setOnClickListener(v->playClip(clipStart,12000));
    }
    if(revealFullSongButton&&!titleSolved&&!artistSolved){
      Button reveal=button("▶ REPRODUCIR CANCIÓN COMPLETA");
      content.addView(reveal);reveal.setOnClickListener(v->playFullSong());
    }
    content.addView(text("Turno: "+players.get(playerIndex),20,0xff172554,true));
    timerText=text("15",42,0xff172554,true);timerText.setGravity(Gravity.CENTER);content.addView(timerText);
    startTurnButton=button("INICIAR TURNO · 15 SEGUNDOS");startTurnButton.setTextSize(17);content.addView(startTurnButton);startTurnButton.setOnClickListener(v->startTimer());
    content.addView(text("PUNTUAR A "+players.get(playerIndex)+" (concursante)",14,0xff334155,true));
    int songPts=new int[]{8,6,4,2}[round], artistPts=new int[]{4,3,2,1}[round];
    LinearLayout points=new LinearLayout(this);points.setOrientation(LinearLayout.VERTICAL);content.addView(points);
    Button songButton=button(titleSolved?"✓ TÍTULO YA ADIVINADO":"ACERTÓ TÍTULO · +"+songPts);points.addView(songButton);songButton.setEnabled(!titleSolved);
    songButton.setOnClickListener(v->{if(!titleSolved){titleSolved=true;scores[playerIndex]+=songPts;refreshScoreboard();songButton.setText("✓ TÍTULO YA ADIVINADO");songButton.setEnabled(false);if(artistSolved)bothAnswersSolved();}});
    Button artistButton=button(artistSolved?"✓ ARTISTA YA ADIVINADO":"ACERTÓ ARTISTA · +"+artistPts);points.addView(artistButton);artistButton.setEnabled(!artistSolved);
    artistButton.setOnClickListener(v->{if(!artistSolved){artistSolved=true;scores[playerIndex]+=artistPts;refreshScoreboard();artistButton.setText("✓ ARTISTA YA ADIVINADO");artistButton.setEnabled(false);if(titleSolved)bothAnswersSolved();}});
    scoreboardText=text(scoreboard(),15,0xff172554,true);content.addView(scoreboardText);
    nextButton=button(players.size()==2?"SIGUIENTE PRUEBA / TURNO":"SIGUIENTE JUGADOR");content.addView(nextButton);nextButton.setOnClickListener(v->advancePlayer());
    Button nextSong=button("SIGUIENTE CANCIÓN");content.addView(nextSong);nextSong.setOnClickListener(v->nextSong());
    content.addView(text("El árbitro no concursa en esta canción. El árbitro rota en cada canción.",12,0xff64748b,false));
  }
  void bothAnswersSolved(){
    revealFullSongButton=false;
    toast(songIndex==sampledTracks.size()-1?"Título y artista resueltos. Reproduciendo; después termina la partida.":"Título y artista resueltos. Reproduciendo; después pasa a la siguiente canción.");
    playFullSong();
  }
  void changeCurrentSong(){
    if((round!=0&&round!=2)||titleSolved||artistSolved){toast("La canción solo se puede cambiar en las pruebas musicales, antes de acertar las respuestas.");return;}
    if(folderUri==null){toast("No se encuentra la carpeta de música.");return;}
    base(0xffeaf2ff);content.addView(text("Buscando otra canción…",18,0xff172554,true));
    worker.execute(()->{
      ArrayList<Track> all=new ArrayList<>();collectAllAudio(folderUri,DocumentsContract.getTreeDocumentId(folderUri),all);
      HashSet<String> already=new HashSet<>();for(int i=0;i<songIndex;i++)already.add(sampledTracks.get(i).uri.toString());
      for(int i=songIndex+1;i<sampledTracks.size();i++)already.add(sampledTracks.get(i).uri.toString());
      already.add(sampledTracks.get(songIndex).uri.toString());
      ArrayList<Track> choices=new ArrayList<>();for(Track candidate:all)if(!already.contains(candidate.uri.toString()))choices.add(candidate);
      if(choices.isEmpty()){runOnUiThread(()->{toast("No hay otra canción disponible en esa carpeta que no esté ya seleccionada.");showRound();});return;}
      Track replacement=choices.get(new Random().nextInt(choices.size()));readMetadata(replacement);
      runOnUiThread(()->{stopAudio();sampledTracks.set(songIndex,replacement);titleSolved=false;artistSolved=false;round1Start=0;round3Start=0;revealFullSongButton=false;roundOneStarted=false;loadClues(replacement);showRound();toast("Canción sustituida. La descartada no se repetirá en esta partida.");});
    });
  }
  void collectAllAudio(Uri tree,String parent,ArrayList<Track> out){
    Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,parent);
    String[] cols={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
    try(android.database.Cursor c=getContentResolver().query(children,cols,null,null,null)){
      if(c==null)return;while(c.moveToNext()){String id=c.getString(0),name=c.getString(1),mime=c.getString(2);
        if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){collectAllAudio(tree,id,out);continue;}
        if(mime!=null&&mime.startsWith("audio/")){Track t=new Track();t.uri=DocumentsContract.buildDocumentUriUsingTree(tree,id);t.fileName=name==null?"Audio":name;out.add(t);}
      }
    }catch(Exception ignored){}
  }
  String contestantsLabel(){StringBuilder b=new StringBuilder();for(int i=0;i<players.size();i++)if(i!=refereeIndex){if(b.length()>0)b.append(" · ");b.append(players.get(i));}return b.toString();}
  String clueForRound(Track t){switch(round){case 1:return t.lyricClue.isEmpty()?"Letra no encontrada automáticamente; el árbitro puede introducir una frase.":t.lyricClue;case 3:return t.spanishClue.isEmpty()?"Traducción no disponible; el árbitro puede escribir una paráfrasis.":t.spanishClue;default:return "Respuesta correcta: "+t.title+" — "+t.artist;}}
  void refreshClue(){
    Track t=sampledTracks.get(songIndex);
    if(refereeClueText!=null)refereeClueText.setText("Pista para el árbitro: "+clueForRound(t));
    if(lyricSearchButton!=null)lyricSearchButton.setVisibility(round==1&&t.lyricLookupDone&&t.lyricClue.isEmpty()?View.VISIBLE:View.GONE);
  }
  void startTimer(){if(turnActive)return;if(round==0)roundOneStarted=true;turnActive=true;timerExpired=false;secondsLeft=TURN_SECONDS;if(startTurnButton!=null)startTurnButton.setEnabled(false);
    String who=players.get(playerIndex);if(tts!=null){tts.speak(who,TextToSpeech.QUEUE_FLUSH,null,"player_name");handler.postDelayed(()->{if(turnActive&&tts!=null){tts.speak("Ya",TextToSpeech.QUEUE_FLUSH,null,"ready");handler.postDelayed(()->{if(turnActive)tick();},350);}},850);}else{toast(who+"… ¡Ya!");tick();}
  }
  void tick(){if(timerText!=null)timerText.setText(String.valueOf(secondsLeft));if(secondsLeft<=0){turnActive=false;timerExpired=true;if(tts!=null)tts.speak("Tiempo",TextToSpeech.QUEUE_FLUSH,null,null);if(startTurnButton!=null)startTurnButton.setEnabled(true);return;}secondsLeft--;timerRunnable=()->tick();handler.postDelayed(timerRunnable,1000);}
  void stopTimer(){if(timerRunnable!=null)handler.removeCallbacks(timerRunnable);timerRunnable=null;turnActive=false;}
  void advancePlayer(){
    stopTimer();
    if(titleSolved&&artistSolved){return;} // La reproducción completa ya se inició; avanzar explícitamente con SIGUIENTE CANCIÓN.
    int next=(playerIndex+1)%players.size();
    if(next!=refereeIndex){playerIndex=next;showRound();return;}
    // Acabó el turno del último concursante de esta ronda.
    if(round+1<ROUNDS){
      round++;playerIndex=nextContestant(refereeIndex);
      if(round==2)round3Start=0;
      showRound();return;
    }
    // Última ronda: si falta título o artista, ofrecer escuchar la canción completa.
    if(!titleSolved||!artistSolved){
      revealFullSongButton=true;
      showRound();
      return;
    }
    // Si ambas respuestas están resueltas, la transición se hace con el botón de siguiente canción.
  }
  void nextSong(){
    stopTimer();stopAudio();revealFullSongButton=false;songIndex++;round=0;titleSolved=false;artistSolved=false;round1Start=-1;round3Start=0;
    if(songIndex<sampledTracks.size()){
      refereeIndex=songIndex%players.size();playerIndex=nextContestant(refereeIndex);
      roundOneStarted=false;loadClues(sampledTracks.get(songIndex));showRound();
    }else showEnd();
  }
  void playFullSong(){
    Track t=sampledTracks.get(songIndex);stopAudio();
    try{
      player=new MediaPlayer();player.setDataSource(this,t.uri);
      player.setOnPreparedListener(mp->{try{mp.start();}catch(Exception ignored){stopAudio();}});
      player.setOnCompletionListener(mp->{stopAudio();});
      player.setOnErrorListener((mp,w,e)->{stopAudio();toast("No se pudo reproducir ese archivo.");return true;});
      player.prepareAsync();
    }catch(Exception e){toast("Error al abrir el audio completo.");stopAudio();}
  }
  void playClip(long start,long length){
    Track t=sampledTracks.get(songIndex);stopAudio();
    try{
      final MediaPlayer clip=new MediaPlayer();player=clip;clip.setDataSource(this,t.uri);
      clip.setOnPreparedListener(mp->{
        if(player!=mp){try{mp.release();}catch(Exception ignored){}return;}
        try{mp.seekTo((int)Math.max(0,start));mp.start();
          // El temporizador queda asociado a ESTE reproductor: no puede cortar el clip siguiente.
          handler.postDelayed(()->{if(player==mp)stopAudio();},length);
        }catch(Exception ignored){if(player==mp)stopAudio();}
      });
      clip.setOnErrorListener((mp,w,e)->{if(player==mp)stopAudio();toast("No se pudo reproducir ese archivo.");return true;});
      clip.prepareAsync();
    }catch(Exception e){stopAudio();toast("Error al abrir el fragmento.");}
  }
  long randomClipStart(Track t,long avoid){
    long max=Math.max(0,t.durationMs-12000L);
    if(max==0)return 0;
    ArrayList<Long> candidates=new ArrayList<>();
    for(long pos=0;pos<=max;pos+=1000L){
      if(Math.abs(pos-avoid)>=12000L)candidates.add(pos);
    }
    if(candidates.isEmpty()){
      // En pistas cortas no siempre existe otro fragmento separado 12 s.
      for(long pos=0;pos<=max;pos+=1000L)if(pos!=avoid)candidates.add(pos);
    }
    if(candidates.isEmpty())return avoid==0?Math.min(1000L,max):0;
    return candidates.get(new Random().nextInt(candidates.size()));
  }
  void stopAudio(){if(player!=null){try{player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}}
  String scoreboard(){StringBuilder s=new StringBuilder("MARCADOR ACUMULADO\n");for(int i=0;i<players.size();i++)s.append(players.get(i)).append(" · ").append(scores[i]).append(" puntos\n");return s.toString();}
  void refreshScoreboard(){if(scoreboardText!=null)scoreboardText.setText(scoreboard());}
  void showEnd(){stopTimer();stopAudio();gameStarted=false;base(0xffeaf2ff);content.addView(text("¡PARTIDA TERMINADA!",26,0xff172554,true));content.addView(text(scoreboard(),19,0xff172554,true));
    Button rescan=button("NUEVA PARTIDA · MISMA CARPETA, 10 CANCIONES NUEVAS");content.addView(rescan);rescan.setEnabled(folderUri!=null);rescan.setOnClickListener(v->rescanCurrentFolder());
    Button setup=button("CAMBIAR CARPETA / JUGADORES");content.addView(setup);setup.setOnClickListener(v->{sampledTracks.clear();folderReady=false;showSetup();});}
  void rescanCurrentFolder(){if(folderUri==null){showSetup();return;}base(0xfff3f5fa);content.addView(text("Sorteando una nueva selección…",18,0xff18233b,true));worker.execute(()->{ArrayList<Track> reservoir=new ArrayList<>();int[] count={0};scanFolder(folderUri,reservoir,count);for(Track t:reservoir)readMetadata(t);runOnUiThread(()->{sampledTracks.clear();sampledTracks.addAll(reservoir);folderReady=!sampledTracks.isEmpty();if(folderReady){scores=new int[players.size()];beginGame();}else{toast("No se encontraron archivos de audio.");showSetup();}});});}
  void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
  @Override protected void onDestroy(){stopTimer();stopAudio();worker.shutdownNow();if(tts!=null)tts.shutdown();super.onDestroy();}
}
